import { Suspense } from "react"
import SplashScreen from "@/components/splash-screen"
import Dashboard from "@/components/dashboard"

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 dark:from-indigo-950 dark:via-purple-950 dark:to-pink-950">
      <Suspense fallback={<SplashScreen />}>
        <Dashboard />
      </Suspense>
    </main>
  )
}

