"use client"

import { useEffect, useState } from "react"
import { Progress } from "@/components/ui/progress"
import { useTheme } from "next-themes"

export default function SplashScreen() {
  const [progress, setProgress] = useState(0)
  const [status, setStatus] = useState("Loading...")
  const { theme, systemTheme } = useTheme()
  const currentTheme = theme === "system" ? systemTheme : theme

  useEffect(() => {
    const timer = setTimeout(() => {
      if (progress < 100) {
        const newProgress = progress + 1
        setProgress(newProgress)

        if (newProgress < 20) {
          setStatus("Initializing...")
        } else if (newProgress < 60) {
          setStatus("Loading face database...")
        } else {
          setStatus("Almost ready...")
        }
      }
    }, 30)

    return () => clearTimeout(timer)
  }, [progress])

  return (
    <div
      className={`flex flex-col items-center justify-center min-h-screen p-6 ${
        currentTheme === "dark"
          ? "bg-gradient-to-br from-violet-950 via-fuchsia-950 to-pink-950"
          : "bg-gradient-to-br from-violet-500 via-fuchsia-500 to-pink-500"
      }`}
    >
      <div className="relative w-full max-w-md bg-white/90 dark:bg-gray-900/90 backdrop-blur-sm rounded-3xl shadow-2xl p-10 space-y-8 border border-white/50 dark:border-gray-800/50">
        <div className="absolute -top-12 left-1/2 -translate-x-1/2 w-24 h-24 bg-gradient-to-br from-violet-600 to-fuchsia-600 dark:from-violet-500 dark:to-fuchsia-500 rounded-2xl shadow-lg flex items-center justify-center transform rotate-12">
          <div className="w-20 h-20 bg-white dark:bg-gray-900 rounded-xl flex items-center justify-center transform -rotate-12">
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="32"
              height="32"
              viewBox="0 0 24 24"
              fill="none"
              stroke="url(#gradient)"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="text-white"
            >
              <defs>
                <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor={currentTheme === "dark" ? "#a78bfa" : "#8B5CF6"} />
                  <stop offset="100%" stopColor={currentTheme === "dark" ? "#f472b6" : "#EC4899"} />
                </linearGradient>
              </defs>
              <path d="M2 20v-8a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v8" />
              <path d="M4 10V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v4" />
              <path d="M12 4v6" />
              <path d="M2 18h20" />
            </svg>
          </div>
        </div>

        <div className="flex flex-col items-center justify-center space-y-4 pt-10">
          <h1 className="text-3xl font-bold text-center bg-gradient-to-r from-violet-600 to-pink-600 dark:from-violet-400 dark:to-pink-400 text-transparent bg-clip-text">
            Smart Attendance System
          </h1>
          <p className="text-sm text-center text-gray-500 dark:text-gray-400">{status}</p>
        </div>

        <div className="space-y-2">
          <Progress
            value={progress}
            className="h-3 rounded-full bg-gray-100 dark:bg-gray-800"
            indicatorClassName="bg-gradient-to-r from-violet-500 to-fuchsia-500 dark:from-violet-400 dark:to-fuchsia-400"
          />
          <p className="text-xs text-right text-gray-400 dark:text-gray-500">{progress}%</p>
        </div>
      </div>
    </div>
  )
}

