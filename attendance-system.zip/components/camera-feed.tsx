"use client"

import { useRef, useEffect, useState } from "react"

export default function CameraFeed() {
  const videoRef = useRef<HTMLVideoElement>(null)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    let stream: MediaStream | null = null

    async function setupCamera() {
      try {
        stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "user" },
          audio: false,
        })

        if (videoRef.current) {
          videoRef.current.srcObject = stream
        }
      } catch (err) {
        setError("Camera access denied or not available")
        console.error("Error accessing camera:", err)
      }
    }

    setupCamera()

    // Cleanup function
    return () => {
      if (stream) {
        stream.getTracks().forEach((track) => track.stop())
      }
    }
  }, [])

  return (
    <div className="relative rounded-2xl overflow-hidden bg-black aspect-video shadow-lg border-4 border-white dark:border-gray-800">
      {error ? (
        <div className="absolute inset-0 flex items-center justify-center text-white bg-black/80">
          <p>{error}</p>
        </div>
      ) : null}
      <video ref={videoRef} className="w-full h-full object-cover" autoPlay playsInline muted />
      <div className="absolute top-0 left-0 w-full h-full border-8 border-white/20 dark:border-gray-300/10 rounded-2xl pointer-events-none"></div>
    </div>
  )
}

