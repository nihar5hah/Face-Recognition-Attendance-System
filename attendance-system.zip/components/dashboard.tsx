"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Calendar } from "@/components/ui/calendar"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Camera, Download, UserPlus, FileText, Sparkles } from "lucide-react"
import CameraFeed from "@/components/camera-feed"
import { ThemeToggle } from "@/components/theme-toggle"

export default function Dashboard() {
  const [activeTab, setActiveTab] = useState("dashboard")
  const [showCamera, setShowCamera] = useState(false)
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date())

  // Mock data for demonstration
  const attendees = [
    { name: "John Doe", time: "09:15:23" },
    { name: "Jane Smith", time: "09:22:45" },
    { name: "Robert Johnson", time: "09:30:12" },
  ]

  const records = [
    { name: "John Doe", date: "2023-05-15", time: "09:15:23" },
    { name: "Jane Smith", date: "2023-05-15", time: "09:22:45" },
    { name: "Robert Johnson", date: "2023-05-15", time: "09:30:12" },
    { name: "Alice Williams", date: "2023-05-14", time: "08:55:18" },
    { name: "David Brown", date: "2023-05-14", time: "09:05:33" },
  ]

  return (
    <div className="container mx-auto p-4 space-y-6">
      <header className="flex justify-between items-center py-6">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-violet-600 to-fuchsia-600 dark:from-violet-500 dark:to-fuchsia-500 rounded-2xl shadow-lg flex items-center justify-center">
            <Sparkles className="text-white h-6 w-6" />
          </div>
          <h1 className="text-3xl font-bold bg-gradient-to-r from-violet-600 to-pink-600 dark:from-violet-400 dark:to-pink-400 text-transparent bg-clip-text">
            Smart Attendance
          </h1>
        </div>
        <ThemeToggle />
      </header>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
        <TabsList className="grid grid-cols-3 w-full max-w-md mx-auto bg-white/20 dark:bg-black/20 backdrop-blur-sm p-1 rounded-full">
          <TabsTrigger
            value="dashboard"
            className="rounded-full data-[state=active]:bg-gradient-to-r data-[state=active]:from-violet-500 data-[state=active]:to-fuchsia-500 data-[state=active]:text-white"
          >
            Dashboard
          </TabsTrigger>
          <TabsTrigger
            value="register"
            className="rounded-full data-[state=active]:bg-gradient-to-r data-[state=active]:from-violet-500 data-[state=active]:to-fuchsia-500 data-[state=active]:text-white"
          >
            Register
          </TabsTrigger>
          <TabsTrigger
            value="records"
            className="rounded-full data-[state=active]:bg-gradient-to-r data-[state=active]:from-violet-500 data-[state=active]:to-fuchsia-500 data-[state=active]:text-white"
          >
            Records
          </TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-0 rounded-3xl shadow-xl overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-br from-violet-200/30 to-fuchsia-200/30 dark:from-violet-800/20 dark:to-fuchsia-800/20 rounded-bl-full -z-10"></div>
              <CardHeader className="pb-2">
                <CardTitle className="text-xl font-bold">Today's Attendance</CardTitle>
                <CardDescription>Total attendees: {attendees.length}</CardDescription>
              </CardHeader>
              <CardContent>
                <Button
                  className="w-full mb-4 bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-600 hover:to-fuchsia-600 rounded-xl h-12 shadow-md transition-all duration-300 hover:shadow-lg"
                  onClick={() => setShowCamera(!showCamera)}
                >
                  {showCamera ? "Stop Camera" : "Start Camera"}
                  <Camera className="ml-2 h-4 w-4" />
                </Button>

                {showCamera && <CameraFeed />}

                <div className="mt-4">
                  <h3 className="font-medium mb-2">Recent Attendees</h3>
                  <div className="rounded-2xl overflow-hidden border border-violet-100 dark:border-violet-900">
                    <Table>
                      <TableHeader className="bg-gradient-to-r from-violet-100/50 to-fuchsia-100/50 dark:from-violet-900/50 dark:to-fuchsia-900/50">
                        <TableRow>
                          <TableHead>Name</TableHead>
                          <TableHead>Time</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {attendees.map((attendee, index) => (
                          <TableRow key={index} className="hover:bg-violet-50/50 dark:hover:bg-violet-900/30">
                            <TableCell className="font-medium">{attendee.name}</TableCell>
                            <TableCell>{attendee.time}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-0 rounded-3xl shadow-xl overflow-hidden">
              <div className="absolute top-0 left-0 w-32 h-32 bg-gradient-to-br from-pink-200/30 to-purple-200/30 dark:from-pink-800/20 dark:to-purple-800/20 rounded-br-full -z-10"></div>
              <CardHeader>
                <CardTitle className="text-xl font-bold">Quick Stats</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-violet-50 to-fuchsia-50 dark:from-violet-900/30 dark:to-fuchsia-900/30 rounded-2xl">
                  <span className="text-gray-600 dark:text-gray-300">Total Registered</span>
                  <span className="font-bold text-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 dark:from-violet-400 dark:to-fuchsia-400 text-transparent bg-clip-text">
                    24
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-violet-50 to-fuchsia-50 dark:from-violet-900/30 dark:to-fuchsia-900/30 rounded-2xl">
                  <span className="text-gray-600 dark:text-gray-300">Present Today</span>
                  <span className="font-bold text-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 dark:from-violet-400 dark:to-fuchsia-400 text-transparent bg-clip-text">
                    18
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-violet-50 to-fuchsia-50 dark:from-violet-900/30 dark:to-fuchsia-900/30 rounded-2xl">
                  <span className="text-gray-600 dark:text-gray-300">Absent Today</span>
                  <span className="font-bold text-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 dark:from-violet-400 dark:to-fuchsia-400 text-transparent bg-clip-text">
                    6
                  </span>
                </div>
                <div className="flex items-center justify-between p-3 bg-gradient-to-r from-violet-50 to-fuchsia-50 dark:from-violet-900/30 dark:to-fuchsia-900/30 rounded-2xl">
                  <span className="text-gray-600 dark:text-gray-300">Attendance Rate</span>
                  <span className="font-bold text-lg bg-gradient-to-r from-violet-600 to-fuchsia-600 dark:from-violet-400 dark:to-fuchsia-400 text-transparent bg-clip-text">
                    75%
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-0 rounded-3xl shadow-xl overflow-hidden">
              <div className="absolute bottom-0 right-0 w-32 h-32 bg-gradient-to-br from-blue-200/30 to-violet-200/30 dark:from-blue-800/20 dark:to-violet-800/20 rounded-tl-full -z-10"></div>
              <CardHeader>
                <CardTitle className="text-xl font-bold">Quick Actions</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button
                  variant="outline"
                  className="w-full justify-start rounded-xl h-12 border-violet-200 dark:border-violet-800 hover:bg-violet-50/50 dark:hover:bg-violet-900/30 hover:border-violet-300 dark:hover:border-violet-700 transition-all duration-300"
                  onClick={() => setActiveTab("register")}
                >
                  <UserPlus className="mr-2 h-5 w-5 text-violet-500 dark:text-violet-400" />
                  Register New Face
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start rounded-xl h-12 border-violet-200 dark:border-violet-800 hover:bg-violet-50/50 dark:hover:bg-violet-900/30 hover:border-violet-300 dark:hover:border-violet-700 transition-all duration-300"
                  onClick={() => setActiveTab("records")}
                >
                  <FileText className="mr-2 h-5 w-5 text-violet-500 dark:text-violet-400" />
                  View All Records
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start rounded-xl h-12 border-violet-200 dark:border-violet-800 hover:bg-violet-50/50 dark:hover:bg-violet-900/30 hover:border-violet-300 dark:hover:border-violet-700 transition-all duration-300"
                >
                  <Download className="mr-2 h-5 w-5 text-violet-500 dark:text-violet-400" />
                  Export to Excel
                </Button>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="register" className="space-y-4">
          <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-0 rounded-3xl shadow-xl overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-violet-200/30 to-fuchsia-200/30 dark:from-violet-800/20 dark:to-fuchsia-800/20 rounded-bl-full -z-10"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-gradient-to-br from-pink-200/30 to-purple-200/30 dark:from-pink-800/20 dark:to-purple-800/20 rounded-tr-full -z-10"></div>
            <CardHeader>
              <CardTitle className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-pink-600 dark:from-violet-400 dark:to-pink-400 text-transparent bg-clip-text">
                Register New Face
              </CardTitle>
              <CardDescription>Capture a face image and register it in the system</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label htmlFor="name" className="text-sm font-medium text-gray-600 dark:text-gray-300">
                  Full Name
                </label>
                <Input
                  id="name"
                  placeholder="Enter full name"
                  className="rounded-xl h-12 border-violet-200 dark:border-violet-800 focus:border-violet-400 focus:ring-violet-400 dark:focus:border-violet-600 dark:focus:ring-violet-600"
                />
              </div>

              <div className="space-y-4">
                <Button
                  className="w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-600 hover:to-fuchsia-600 rounded-xl h-12 shadow-md transition-all duration-300 hover:shadow-lg"
                  onClick={() => setShowCamera(!showCamera)}
                >
                  {showCamera ? "Stop Camera" : "Start Camera"}
                  <Camera className="ml-2 h-4 w-4" />
                </Button>

                {showCamera ? (
                  <div className="space-y-4">
                    <CameraFeed />
                    <Button className="w-full bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-600 hover:to-fuchsia-600 rounded-xl h-12 shadow-md transition-all duration-300 hover:shadow-lg">
                      Capture Face
                    </Button>
                  </div>
                ) : (
                  <div className="border-2 border-dashed border-violet-200 dark:border-violet-800 rounded-2xl aspect-video bg-violet-50/50 dark:bg-violet-900/20 flex flex-col items-center justify-center p-6">
                    <Camera className="h-16 w-16 text-violet-300 dark:text-violet-700 mb-4" />
                    <p className="text-violet-400 dark:text-violet-500 text-center">
                      Start camera to capture your face
                    </p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="records" className="space-y-4">
          <Card className="bg-white/80 dark:bg-gray-900/80 backdrop-blur-sm border-0 rounded-3xl shadow-xl overflow-hidden">
            <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-br from-violet-200/30 to-fuchsia-200/30 dark:from-violet-800/20 dark:to-fuchsia-800/20 rounded-bl-full -z-10"></div>
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-gradient-to-br from-pink-200/30 to-purple-200/30 dark:from-pink-800/20 dark:to-purple-800/20 rounded-tr-full -z-10"></div>
            <CardHeader>
              <CardTitle className="text-2xl font-bold bg-gradient-to-r from-violet-600 to-pink-600 dark:from-violet-400 dark:to-pink-400 text-transparent bg-clip-text">
                Attendance Records
              </CardTitle>
              <CardDescription>View and filter attendance records</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex flex-col sm:flex-row gap-6 items-start sm:items-end">
                <div className="space-y-2 bg-white dark:bg-gray-800 rounded-2xl p-4 shadow-sm border border-violet-100 dark:border-violet-900">
                  <label className="text-sm font-medium text-gray-600 dark:text-gray-300">Filter by Date</label>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    className="rounded-xl border-violet-100 dark:border-violet-900"
                  />
                </div>

                <div className="flex flex-wrap gap-2">
                  <Button className="bg-gradient-to-r from-violet-500 to-fuchsia-500 hover:from-violet-600 hover:to-fuchsia-600 rounded-xl shadow-md transition-all duration-300 hover:shadow-lg">
                    Apply Filter
                  </Button>
                  <Button
                    variant="outline"
                    className="rounded-xl border-violet-200 dark:border-violet-800 hover:bg-violet-50/50 dark:hover:bg-violet-900/30 hover:border-violet-300 dark:hover:border-violet-700 transition-all duration-300"
                  >
                    Clear Filter
                  </Button>
                  <Button
                    variant="outline"
                    className="rounded-xl border-violet-200 dark:border-violet-800 hover:bg-violet-50/50 dark:hover:bg-violet-900/30 hover:border-violet-300 dark:hover:border-violet-700 transition-all duration-300"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    Export
                  </Button>
                </div>
              </div>

              <div className="rounded-2xl overflow-hidden border border-violet-100 dark:border-violet-900 shadow-sm">
                <Table>
                  <TableHeader className="bg-gradient-to-r from-violet-100/50 to-fuchsia-100/50 dark:from-violet-900/50 dark:to-fuchsia-900/50">
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Date</TableHead>
                      <TableHead>Time</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {records.map((record, index) => (
                      <TableRow key={index} className="hover:bg-violet-50/50 dark:hover:bg-violet-900/30">
                        <TableCell className="font-medium">{record.name}</TableCell>
                        <TableCell>{record.date}</TableCell>
                        <TableCell>{record.time}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

